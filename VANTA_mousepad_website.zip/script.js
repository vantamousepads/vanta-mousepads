// VANTA storefront is intentionally lightweight.
// Replace the mailto order link with your real checkout URL when you're ready.
